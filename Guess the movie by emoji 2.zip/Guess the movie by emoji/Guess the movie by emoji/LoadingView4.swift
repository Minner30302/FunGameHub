//
//  LoadingView4.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 4/8/24.
//
import SwiftUI

struct LoadingView4: View {
    @State private var isLoading = false
    @State private var isLoaded = false // Added state for tracking loading completion
    
    var body: some View {
        NavigationView { // Wrap the content in a NavigationView
            ZStack {
                // Gradient background
                LinearGradient(gradient: Gradient(colors: [Color.blue, Color.red]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                
                VStack {
                    // Spinner animation
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        .scaleEffect(2.0, anchor: .center)
                        .animation(.easeInOut(duration: 1.0).repeatForever(), value: isLoading)
                    
                    // Loading text
                    Text("Loading...")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.top, 20)
                }
                .onAppear {
                    isLoading = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                        isLoading = false
                        isLoaded = true // Mark loading as complete
                    }
                }
                .navigationBarBackButtonHidden(true)
                
                // NavigationLink to transition to another view when loading is complete
                NavigationLink(destination: Level_Select(), isActive: $isLoaded) {
                    EmptyView()
                }
                .hidden() // Hide the NavigationLink visually
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}



#Preview {
    LoadingView4()
}
