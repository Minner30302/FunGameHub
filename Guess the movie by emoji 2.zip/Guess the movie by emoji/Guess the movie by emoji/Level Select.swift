//
//  Level Select.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 3/7/24.
//
import SwiftUI

struct Level_Select: View {
    var body: some View {
        NavigationView {
            ZStack {
                Color.gray.ignoresSafeArea()
                
                // Circles
                Circle()
                    .frame(width: 300, height: 300)
                    .offset(x: -150, y: -390)
                    .foregroundColor(.green)
                    .shadow(color: .black, radius: 20)
                
                Circle()
                    .frame(width: 300, height: 300)
                    .offset(x: 150, y: 390)
                    .foregroundColor(.green)
                    .shadow(color: .black, radius: 20)
                
                Circle()
                    .frame(width: 150, height: 150)
                    .offset(x: -150, y: -390)
                    .foregroundColor(.blue)
                    .shadow(color: .black, radius: 30)
                
                Circle()
                    .frame(width: 150, height: 150)
                    .offset(x: 150, y: 390)
                    .foregroundColor(.blue)
                    .shadow(color: .black, radius: 30)
                
                VStack(spacing: -13) {
                    Text("Select a Game")
                        .font(.largeTitle)
                        .fontDesign(.rounded)
                        .foregroundColor(.white)
                        .offset(y: -47)
                        .shadow(color: .black, radius: 20)
                    
                    VStack(spacing: 20) {
                        NavigationLink(destination: TicTacToe()) {
                            Text("Tic Tac Toe")
                                .frame(width: 200, height: 30) // Adjusted width to fit better
                                .foregroundColor(.black)
                                .background(Color.cyan)
                                .clipShape(Capsule())
                        }
                        .shadow(color: .black, radius: 10)
                        .padding(30)
                        NavigationLink(destination: GuessLevel_Select()) {
                            Text("Guessing Game")
                                .frame(width: 200, height: 30) // Adjusted width to fit better
                                .foregroundColor(.black)
                                .background(Color.cyan)
                                .clipShape(Capsule())
                        }
                        .shadow(color: .black, radius: 10)
                        .padding(30)
                        NavigationLink(destination: GuessPage3()) {
                            Text("✨Surprise✨")
                                .frame(width: 200, height: 30) // Adjusted width to fit better
                                .foregroundColor(.black)
                                .background(Color.cyan)
                                .clipShape(Capsule())
                        }
                        .shadow(color: .black, radius: 10)
                        .padding(30)
                        NavigationLink(destination: WarCardGame()) {
                            Text("WarCardGame")
                                .frame(width: 200, height: 30) // Adjusted width to fit better
                                .foregroundColor(.black)
                                .background(Color.cyan)
                                .clipShape(Capsule())
                        }
                        .shadow(color: .black, radius: 10)
                        .padding(30)
                        
                        NavigationLink(destination: HangMan()) {
                            Text("HangMan")
                                .frame(width: 200, height: 30) // Adjusted width to fit better
                                .foregroundColor(.black)
                                .background(Color.cyan)
                                .clipShape(Capsule())
                        }
                        .shadow(color: .black, radius: 10)
                        .padding(30)
                        
                        NavigationLink(destination: LoadingMM()) {
                            Text("Main Menu")
                                .frame(width: 200, height: 30) // Adjusted width to fit better
                                .foregroundColor(.black)
                                .background(Color.cyan)
                                .clipShape(Capsule())
                        }
                        .shadow(color: .black, radius: 10)
                        .padding(30)
                    }
                    .padding(.horizontal, 50)
                    
                    Spacer()
                }
                .padding(.vertical, 100) // Adjusted vertical padding
            }
        }
        .navigationBarHidden(true) // Hide the navigation bar globally
        .navigationBarBackButtonHidden(true) // Hide the back button specifically for this view
        .navigationViewStyle(StackNavigationViewStyle()) // Use StackNavigationViewStyle for better behavior in the preview
    }
}

struct Level_Select_Previews: PreviewProvider {
    static var previews: some View {
        Level_Select()
    }
}

