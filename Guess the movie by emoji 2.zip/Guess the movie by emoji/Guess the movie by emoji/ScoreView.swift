//
//  ScoreView.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 4/16/24.
//
import SwiftUI

struct ScoreView: View {
    var score: Int
    
    var body: some View {
        HStack {
            Spacer()
            Text("Score: \(score)")
                .font(.headline)
                .foregroundColor(.white)
                .padding()
            Spacer()
        }
        .background(Color.blue)
    }
}
