//
//  SingleBackButtonModifier.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 4/16/24.
//
//import SwiftUI
//
//struct CustomNavigationView<Content>: View where Content: View {
//    let content: Content
//    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
//    
//    init(@ViewBuilder content: () -> Content) {
//        self.content = content()
//    }
//    
//    var body: some View {
//        NavigationView {
//            content
//                .navigationBarBackButtonHidden(true)
//                .navigationBarItems(
//                    leading: BackButtonDisabler(action: {
//                        self.presentationMode.wrappedValue.dismiss()
//                    })
//                )
//        }
//    }
//}
//
//struct BackButtonDisabler: View {
//    let action: () -> Void
//    
//    var body: some View {
//        Button(action: action) {
//            Image(systemName: "chevron.left")
//                .padding()
//                .foregroundColor(.black)
//        }
//        .disabled(true) // Disable the back button
//    }
//}
//import SwiftUI
//
//struct CustomNavigationView<Content>: View where Content: View {
//    let content: Content
//    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
//    
//    init(@ViewBuilder content: () -> Content) {
//        self.content = content()
//    }
//    
//    var body: some View {
//        NavigationView {
//            content
//                .navigationBarBackButtonHidden(true)
//                .navigationBarItems(
//                    leading: BackButtonDisabler {
//                        self.presentationMode.wrappedValue.dismiss()
//                    }
//                )
//        }
//    }
//}
//
//struct BackButtonDisabler: View {
//    let action: () -> Void
//    
//    var body: some View {
//        Button(action: action) {
//            Image(systemName: "chevron.left")
//                .padding()
//                .foregroundColor(.black)
//        }
//        .disabled(true) // Disable the back button
//    }
//}
//
//struct ContentView: View {
//    @State private var showDetail = false
//    
//    var body: some View {
//        CustomNavigationView {
//            VStack {
//                NavigationLink(destination: DetailView(), isActive: $showDetail) {
//                    Text("Go to Detail View")
//                }
//                .navigationBarTitle("Main View")
//            }
//        }
//        .navigationViewStyle(StackNavigationViewStyle()) // Add this line to use StackNavigationViewStyle
//    }
//}
//
//struct DetailView: View {
//    var body: some View {
//        VStack {
//            Text("Detail View")
//        }
//    }
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
