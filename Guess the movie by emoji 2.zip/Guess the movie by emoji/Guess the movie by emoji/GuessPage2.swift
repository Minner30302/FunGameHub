//
//  GuessPage2.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 3/8/24.
//
import SwiftUI

struct GuessPage2: View {
    @State var Movie1Showing: Bool = false
    @State var ColorOne: Color = .green
    @State var Movie2Showing: Bool = false
    @State var ColorTwo: Color = .green
    @State var Movie3Showing: Bool = false
    @State var ColorThree: Color = .green
    @State var Movie4Showing: Bool = false
    @State var ColorFour: Color = .green
    @State var Movie5Showing: Bool = false
    @State var ColorFive: Color = .green
    @State var Movie6Showing: Bool = false
    @State var ColorSix: Color = .green
    @State var Movie7Showing: Bool = false
    @State var ColorSeven: Color = .green
    @State var Movie8Showing: Bool = false
    @State var ColorEight: Color = .green
    
    @State private var textColor: Color = .white
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.12), Color.blue.opacity(0.8)]), startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        Text("Guess the Characters by Emoji")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(textColor)
                            .border(Color.black, width: 1)
                            .scaleEffect(1.2)
                            .padding()
                            .lineLimit(1)
                            .minimumScaleFactor(0.5)
                            .padding(.top, 20)
                        
                        NavigationLink(destination: LoadingCHMM()) {
                            Text("Back to Start")
                                .frame(width: 150, height: 40)
                                .foregroundColor(.white)
                                .background(Color.blue)
                                .clipShape(Capsule())
                                .shadow(color: .black, radius: 10)
                        }
                        
                        Divider()
                        
                        EmojiButton(action: {
                            self.Movie1Showing.toggle()
                            self.ColorOne = .cyan
                        }, emoji: "⚡️🏃🏻", movieName: "The Flash", imageName: "flash", isPresented: $Movie1Showing, buttonColor: $ColorOne)
                        
                        Divider()
                        
                        EmojiButton(action: {
                            self.Movie2Showing.toggle()
                            self.ColorTwo = .cyan
                        }, emoji: "🦇 🧔🏻", movieName: "batman", imageName: "batman", isPresented: $Movie2Showing, buttonColor: $ColorTwo)
                        
                        Divider()
                        
                        EmojiButton(action: {
                            self.Movie3Showing.toggle()
                            self.ColorThree = .cyan
                        }, emoji: "⚡️🧔🏻🦸🏻", movieName: "Shazam", imageName: "shazam", isPresented: $Movie3Showing, buttonColor: $ColorThree)
                        
                        Divider()
                        
                        EmojiButton(action: {
                            self.Movie4Showing.toggle()
                            self.ColorFour = .cyan
                        }, emoji: "🐟🧔🏻", movieName: "Aquaman", imageName: "aquaman", isPresented: $Movie4Showing, buttonColor: $ColorFour)
                        
                        Divider()
                        
                        EmojiButton(action: {
                            self.Movie5Showing.toggle()
                            self.ColorFive = .cyan
                        }, emoji: "🧔🏻🕶️👕", movieName: "Superman", imageName: "superman", isPresented: $Movie5Showing, buttonColor: $ColorFive)
                        
                        Divider()
                        
                        EmojiButton(action: {
                            self.Movie6Showing.toggle()
                            self.ColorSix = .cyan
                        }, emoji: "🔴🧔🏻⚔️", movieName: "Deadpool", imageName: "deadpool", isPresented: $Movie6Showing, buttonColor: $ColorSix)
                        
                        Divider()
                    }
                    .padding()
                }
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}

struct EmojiButton: View {
    let action: () -> Void
    let emoji: String
    let movieName: String
    let imageName: String
    @Binding var isPresented: Bool
    @Binding var buttonColor: Color
    
    var body: some View {
        Button(action: action) {
            Text(emoji)
                .font(.title)
                .padding(20)
        }
        .foregroundColor(.white)
        .background(buttonColor)
        .clipShape(Capsule())
        .font(.title)
        .sheet(isPresented: $isPresented) {
            VStack {
                Text(movieName)
                    .font(.largeTitle)
                
                Image(imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 200, height: 200)
                
                Button("Dismiss") {
                    isPresented.toggle()
                    buttonColor = .green
                }
                .frame(width: 200, height: 30)
                .background(Color.blue)
                .foregroundColor(.white)
                .clipShape(Capsule())
            }
        }
        .padding(25)
    }
}

struct GuessPage2_Previews: PreviewProvider {
    static var previews: some View {
        GuessPage2()
    }
}
