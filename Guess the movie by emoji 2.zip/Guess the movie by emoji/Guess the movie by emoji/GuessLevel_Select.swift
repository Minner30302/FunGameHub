//
//  GuessLevel_Select.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 4/16/24.
//
import SwiftUI

struct GuessLevel_Select: View {
    @State private var gradientColors: [Color] = [.blue, .purple]
    @State private var isAnimated = false
        
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(gradient: Gradient(colors: gradientColors), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .edgesIgnoringSafeArea(.all)
                    .onAppear {
                        withAnimation(Animation.linear(duration: 5).repeatForever()) {
                            isAnimated = true
                            gradientColors = [.purple, .blue] // Change to your desired colors
                        }
                    }
                
                VStack(spacing: 30) {
                    Text("Choose a Guessing Game")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                    
                    VStack(spacing: 20) {
                        NavigationLink(destination: LoadingViewGP()) {
                            Text("Movie By Emoji")
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .frame(height: 50)
                                .background(Color.green)
                                .cornerRadius(25)
                                .shadow(color: Color.green.opacity(0.7), radius: 10, x: 0, y: 5)
                                .padding(.horizontal, 30)
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        NavigationLink(destination: LoadingViewG2()) {
                            Text("Character By Emoji")
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .frame(height: 50)
                                .background(Color.green)
                                .cornerRadius(25)
                                .shadow(color: Color.green.opacity(0.7), radius: 10, x: 0, y: 5)
                                .padding(.horizontal, 30)
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        
                        NavigationLink(destination: Level_Select()) {
                            Text("Exit")
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                                .frame(width: 95)
                                .frame(height: 50)
                                .background(Color.green)
                                .cornerRadius(25)
                                .shadow(color: Color.green.opacity(0.7), radius: 10, x: 0, y: 5)
                                .padding(.horizontal, 30)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                    .padding(.horizontal, 20)
                    
                    Spacer()
                }
                
                
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}

struct GuessLevel_Select_Previews: PreviewProvider {
    static var previews: some View {
        GuessLevel_Select()
            .preferredColorScheme(.dark) // Preview in dark mode
    }
}
