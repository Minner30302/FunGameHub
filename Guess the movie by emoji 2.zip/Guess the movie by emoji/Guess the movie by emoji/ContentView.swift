//
//  ContentView.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 3/5/24.
//

import SwiftUI

struct ContentView: View {
    
    @State private var circleColorIndex = 0
    private let colors: [Color] = [.red, .green, .blue, .orange, .yellow, .purple]
    
    var body: some View {
        NavigationView {
            ZStack{
                Color.blue.ignoresSafeArea()
                
                Circle()
                    .frame(width:330,height: 330)
                    .offset(x:-150,y:-390)
                    .foregroundColor(colors[circleColorIndex])
                
                Circle()
                    .frame(width:220,height: 220)
                    .offset(x:-150,y:-390)
                    .foregroundColor(.blue)
                    .shadow(color: Color.black, radius: 10)
                
                Circle()
                    .frame(width:330,height: 330)
                    .offset(x:150,y:390)
                    .foregroundColor(colors[circleColorIndex])
                
                Circle()
                    .frame(width:220,height: 220)
                    .offset(x:150,y:390)
                    .foregroundColor(.blue)
                    .shadow(color: Color.black, radius: 10)
                
                VStack {
                    Text("Ᏽ𐌵𐌄𐌔𐌔 𐌕𐋅𐌄 𐌌0ᕓ𐌉𐌄/𐌕ᕓ-𐌔𐋅0Ꮤ/𐌂𐋅𐌀𐌓𐌀𐌂𐌕𐌄𐌓 𐌁𐌙 𐌄𐌌0Ꮭ𐌉")
                        .font(.largeTitle)
                        .fontDesign(.rounded)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                        .padding(.top, 30)
                    
                    Text("😀           😎")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                    
                    NavigationLink(destination: LoadingView4()) { // Replace LoadingView4 with your destination view
                        Text("Start")
                            .frame(width: 200, height: 70)
                            .font(.title)
                            .foregroundColor(.white)
                            .background(Color.green)
                            .clipShape(Capsule())
                            .shadow(color: .black, radius: 10)
                    }
                    .padding(.top, 30)
                }
            }
       
            .onAppear {
                // Change the color of the circles with animation
                withAnimation(Animation.easeInOut(duration: 3.0).repeatForever()) {
                    circleColorIndex = (circleColorIndex + 1) % colors.count
                }
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}

#if DEBUG
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
