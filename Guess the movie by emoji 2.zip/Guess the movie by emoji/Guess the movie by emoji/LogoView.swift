//
//  LogoView.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 4/15/24.
//
import SwiftUI

struct AppLogo: View {
    var body: some View {
        VStack {
            Image("your_logo_image_name") // Replace "your_logo_image_name" with the actual name of your logo image
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100, height: 100)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white, lineWidth: 3))
                .shadow(radius: 5)
            
            Text("Your App Name")
                .font(.headline)
                .foregroundColor(.black)
        }
    }
}

struct AppLogo_Previews: PreviewProvider {
    static var previews: some View {
        AppLogo()
    }
}
