//
//  Rock,Paper,Scissors.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 4/11/24.
//
import SwiftUI

enum Choices: String, CaseIterable {
    case Scissor = "✂️", Paper = "📄", Rock = "🪨"
}

struct Rock_Paper_Scissors: View {
    
    @State private var computerChoice = Choices.allCases.first!
    @State private var playerChoice: Choices?
    @State private var gameOutcome = ""
    @State private var wins = 0
    @State private var round = 0
    @State private var loss = 0
    @State private var showComputerChoice = false
    @State private var gameEnded = false
    @State private var gradientColors: [Color] = [.blue, .green]
    @State private var isAnimated = false
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: gradientColors), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                    .onAppear {
                        withAnimation(Animation.easeInOut(duration: 2.0).repeatForever()) {
                            isAnimated = true
                            gradientColors = [.green, .orange] // Change to contrasting colors
                        }
                    }
                
                VStack {
                    Text("Rock Paper Scissors Game")
                        .font(.title)
                        .foregroundColor(.white)
                        .padding()
                    
                    Text("Round: \(round)")
                        .font(.headline)
                        .foregroundColor(.white)
                        .fixedSize(horizontal: false, vertical: true) // Ensure fixed height
                    
                    HStack(spacing: 20) {
                        ForEach(Choices.allCases, id: \.self) { option in
                            Button(action:{
                                startRound(with: option)
                            }) {
                                Text(option.rawValue)
                                    .font(.title)
                                    .padding(30)
                                    .foregroundColor(.white)
                                    .background(LinearGradient(gradient: Gradient(colors: [Color.orange, Color.red]), startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .clipShape(Circle())
                                    .shadow(color: Color.black.opacity(0.4), radius: 10, x: 0, y: 5)
                            }
                        }
                    }
                    .padding()
                    
                    HStack {
                        Text("You: \(wins)")
                            .font(.headline)
                            .foregroundColor(.white)
                            .fixedSize(horizontal: false, vertical: true) // Ensure fixed height
                        Spacer()
                        Text("Computer: \(loss) \(computerChoice.rawValue)") // Display computer's choice emoji
                            .font(.headline)
                            .foregroundColor(.white)
                            .fixedSize(horizontal: false, vertical: true) // Ensure fixed height
                    }
                    .padding(.horizontal)
                    
                    if let playerChoice = playerChoice {
                        Text("You chose: \(playerChoice.rawValue)")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                    }
                    
                    if showComputerChoice {
                        Text("Computer chose: \(computerChoice.rawValue)")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .animation(.easeInOut(duration: 0.5), value: showComputerChoice) // Fix animation here
                    }
                    
                    Spacer() // Add spacer at the bottom
                }
                .fullScreenCover(isPresented: $gameEnded) {
                    GameResultView(wins: wins, losses: loss)
                }
                
                // Custom back button
                VStack {
                    Spacer()
                    Button(action: {
                        // Handle back button tap
                        gameEnded = true
                    }) {
                        Text("Back")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(8)
                    }
                    .padding()
                }
            }
            .onAppear {
                reset()
            }
            .navigationBarTitle("")
            .navigationBarBackButtonHidden(true) // Hide the default back button
            .navigationBarHidden(true) // Hide the navigation bar completely
        }
    }
    
    func startRound(with playerChoice: Choices) {
        self.playerChoice = playerChoice
        
        round += 1
        
        if round >= 20 {
            gameEnded = true
        } else {
            // Continue the game
            let index = Int.random(in: 0..<Choices.allCases.count)
            computerChoice = Choices.allCases[index]
            showComputerChoice = true
            
            switch playerChoice {
            case .Scissor:
                switch computerChoice {
                case .Scissor:
                    gameOutcome = "Draw"
                case .Paper:
                    gameOutcome = "Win"
                    wins += 1
                case .Rock:
                    gameOutcome = "Lose"
                    loss += 1
                }
            case .Paper:
                switch computerChoice {
                case .Scissor:
                    gameOutcome = "Lose"
                    loss += 1
                case .Paper:
                    gameOutcome = "Draw"
                case .Rock:
                    gameOutcome = "Win"
                    wins += 1
                }
            case .Rock:
                switch computerChoice {
                case .Scissor:
                    gameOutcome = "Win"
                    wins += 1
                case .Paper:
                    gameOutcome = "Lose"
                    loss += 1
                case .Rock:
                    gameOutcome = "Draw"
                }
            }
            showComputerChoice = true
        }
    }
    
    func reset() {
        wins = 0
        loss = 0
        round = 0
        gameEnded = false
        playerChoice = nil
        gameOutcome = ""
        showComputerChoice = false
    }
}

struct Rock_Paper_Score: View {
    let wins: Int
    let losses: Int
    
    var body: some View {
        VStack {
            Text("Game Over")
                .font(.title)
                .padding()
            
            Text("Wins: \(wins)")
            Text("Losses: \(losses)")
            
            Button("Play Again") {
                // Reset the game
            }
            .padding()
        }
    }
}

struct Rock_Paper_Scissors_Previews: PreviewProvider {
    static var previews: some View {
        Rock_Paper_Scissors()
    }
}
