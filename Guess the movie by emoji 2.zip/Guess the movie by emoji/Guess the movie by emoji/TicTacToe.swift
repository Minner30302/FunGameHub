//
//  TicTacToe.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 4/16/24.
//
import SwiftUI

struct TicTacToe: View {
    @State private var board = Array(repeating: Array(repeating: "", count: 3), count: 3)
    @State private var currentPlayer = "X"
    @State private var winner = ""
    @State private var playerWon = false
    @State private var gradientColors: [Color] = [Color.blue, Color.purple, Color.green]
    @State private var currentGradientIndex = 0
    @State private var isWinnerHighlighted = false
    
    @Environment(\.dismiss) var dismiss
    
    @AppStorage("player1Name") var player1Name: String = ""
    @AppStorage("player2Name") var player2Name: String = ""
    //    @State private var player1Score = 0
    //    @State private var player2Score = 0
    
    var body: some View {
        
        NavigationView {
            ZStack {
                backgroundGradient
                mainContent
            }
            .navigationBarHidden(false)
//            .navigationBarItems(trailing: 
//                                    Button(action: {
//                reset()
//            }, label: {
//                Text("Reset")
//                    .padding(.horizontal, 4)
//                    .background(.gray.opacity(0.6))
//                    .cornerRadius(300)
//                    .foregroundStyle(Color.black)
//            })
//            )
            .toolbar {
                ToolbarItemGroup(placement: .primaryAction) {
                    Button("Exit Game") {
                       dismiss()
                    }
                    .background(Color.gray)
                    .cornerRadius(10)
                    
//                    Button(action: {
//                        reset()
//                    }, label: {
//                        Text("Reset").padding()
//                            .background(Color.gray)
//                    })
//                    
                    Button("Reset") {
                        reset()
                    }
                    .padding(.trailing, 8)
                    .background(Color.gray)
                    .cornerRadius(10)
                }
            }
                
        }
        .navigationBarBackButtonHidden(true)
        .onAppear {
            player1Name = ""
            player2Name = ""
        }
    }
    
    private var backgroundGradient: some View {
        let firstColorIndex = currentGradientIndex % gradientColors.count
        let secondColorIndex = (currentGradientIndex + 1) % gradientColors.count
        let gradient = Gradient(colors: [gradientColors[firstColorIndex], gradientColors[secondColorIndex]])
        
        return LinearGradient(gradient: gradient, startPoint: .top, endPoint: .bottom)
            .ignoresSafeArea()
            .onAppear {
                withAnimation(Animation.easeInOut(duration: 4.0).repeatForever()) {
                    currentGradientIndex = (currentGradientIndex + 1) % gradientColors.count
                }
            }
    }
    
    private var mainContent: some View {
        VStack(spacing: 20) {
            gameTitle
            playerNamesInput
            gameBoard
            if !winner.isEmpty {
                gameResult
            }
        }
        .padding()
    }
    
    private var gameTitle: some View {
        Text("Tic Tac Toe")
            .font(.largeTitle)
            .fontWeight(.bold)
            .foregroundColor(.white)
            .padding(.top, 50)
    }
    
    private var playerNamesInput: some View {
        VStack {
            TextField("Player 1 Name", text: $player1Name)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal)
                .padding(.bottom, 10)
            TextField("Player 2 Name", text: $player2Name)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal)
                .padding(.bottom, 20)
        }
    }
    
    private var gameBoard: some View {
        VStack(spacing: 10) {
            ForEach(0..<3) { row in
                HStack(spacing: 10) {
                    ForEach(0..<3) { col in
                        Button(action: {
                            if board[row][col].isEmpty && winner.isEmpty {
                                board[row][col] = currentPlayer
                                checkGame(row: row, col: col)
                                currentPlayer = currentPlayer == "X" ? "O" : "X"
                            }
                        }) {
                            ZStack {
                                Circle()
                                    .fill(Color.white.opacity(0.8))
                                    .frame(width: 80, height: 80)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 10)
                                            .stroke(Color.black, lineWidth: 2)
                                    )
                                
                                Text(board[row][col])
                                    .font(.system(size: 40, weight: .bold))
                                    .foregroundColor(.black)
                            }
                        }
                        .scaleEffect(isWinnerHighlighted && isWinningMove(row: row, col: col) ? 1.2 : 1.0)
                        .rotationEffect(.degrees(board[row][col] == "O" ? 360 : 0))
                        .animation(.easeInOut(duration: 0.3))
                    }
                }
            }
        }
        .padding()
        .background(Color.black.opacity(0.6))
        .cornerRadius(20)
        .padding(.horizontal)
    }
    
    private var gameResult: some View {
        if winner == "Tie" {
            return Text("It's a Tie!")
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.purple)
                .padding()
                .animation(.default)
                .eraseToAnyView()
        } else {
            return Text("Winner: \(winner == "X" ? player1Name : player2Name)")
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(winner == "X" ? .blue : .green)
                .padding(.bottom, 20)
                .animation(.default)
                .eraseToAnyView()
        }
    }
    
    func reset() {
        board = Array(repeating: Array(repeating: "", count: 3), count: 3)
        
        currentPlayer = "X"
        playerWon = false
        winner = ""
    }
    
    
    
    
    private func checkGame(row: Int, col: Int) {
        if isBoardFull() {
            winner = "Tie"
        } else if isWinningMove(row: row, col: col) {
            winner = currentPlayer
            if currentPlayer == "X" {
//                player1Score += 1
            } else {
//                player2Score += 1
            }
        }
    }
    
    private func isBoardFull() -> Bool {
        for row in board {
            for cell in row {
                if cell.isEmpty {
                    return false
                }
            }
        }
        return true
    }
    
    private func isWinningMove(row: Int, col: Int) -> Bool {
        // Check rows
        if board[row][0] == currentPlayer && board[row][1] == currentPlayer && board[row][2] == currentPlayer {
            return true
        }
        
        // Check columns
        if board[0][col] == currentPlayer && board[1][col] == currentPlayer && board[2][col] == currentPlayer {
            return true
        }
        
        // Check diagonals
        if (row == col && board[0][0] == currentPlayer && board[1][1] == currentPlayer && board[2][2] == currentPlayer) ||
            (row + col == 2 && board[0][2] == currentPlayer && board[1][1] == currentPlayer && board[2][0] == currentPlayer) {
            return true
        }
        
        // Check sides
        if board[0][col] == currentPlayer && board[1][1] == currentPlayer && board[2][col] == currentPlayer {
            return true
        }
        if board[row][0] == currentPlayer && board[1][1] == currentPlayer && board[row][2] == currentPlayer {
            return true
        }
        
        return false
    }


}

struct TicTacToe_Previews: PreviewProvider {
    static var previews: some View {
        TicTacToe()
    }
}

extension View {
    func eraseToAnyView() -> AnyView {
        AnyView(self)
    }
}
