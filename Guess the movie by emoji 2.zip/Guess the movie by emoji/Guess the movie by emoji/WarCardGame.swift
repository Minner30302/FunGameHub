//
//  WarCardGame.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 4/15/24.
//
import SwiftUI

struct WarCardGame: View {
    @State var playerCard = "card7"
    @State var cpuCard = "card13"
    @State var playerScore = 0
    @State var cpuScore = 0
    @State private var gameEnded = false
    @State private var winner = ""
    @State private var gradientColors: [Color] = [.red, .black, .red]
    @State private var isAnimated = false
    

    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: gradientColors), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .edgesIgnoringSafeArea(.all)
//                    .onAppear {
//                        withAnimation(Animation.easeInOut(duration: 3).repeatForever()) {
//                            isAnimated = true
//                            gradientColors = [.red, .black, .red] // Adjust colors as needed
//                        }
//                    }
                
                VStack {
                    Spacer()
                    Image("logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 150)
                        .padding(.bottom, 30)
                    Spacer()
                    
                    HStack {
                        Spacer()
                        Image(playerCard)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 180)
                        Spacer()
                        Image(cpuCard)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 180)
                        Spacer()
                    }
                    .padding(.horizontal)
                    Spacer()
                    
                    Button {
                        //                        DispatchQueue.main.async {
                        deal()
                        //}
                    } label: {
                        Text("Deal Cards")
                            .font(.title3)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.green)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                    }
                    .padding(.bottom, 20)
                    
                    HStack {
                        Spacer()
                        VStack(alignment: .center) {
                            Text("Player")
                                .font(.headline)
                                .foregroundColor(.white)
                            Text("\(playerScore)")
                                .font(.title)
                                .foregroundColor(.white)
                        }
                        Spacer()
                        VStack(alignment: .center) {
                            Text("CPU")
                                .font(.headline)
                                .foregroundColor(.white)
                            Text("\(cpuScore)")
                                .font(.title)
                                .foregroundColor(.white)
                        }
                        Spacer()
                    }
                    
                    Spacer()
                    
                    NavigationLink(destination: Level_Select()) {
                        Text("Go to Level Select")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                    .padding(.bottom, 20)
                    .transition(.slide)
                }
            }
            .alert(isPresented: $gameEnded) {
                Alert(
                    title: Text("Game Over"),
                    message: Text("\(winner) wins!"),
                    dismissButton: .default(Text("Play Again")) {
                        resetGame()
                    }
                )
            }
//            .navigationBarTitle("", displayMode: .inline) // Custom navigation bar title with empty string
            .navigationBarHidden(true) // Hide the navigation bar globally
            .navigationBarBackButtonHidden(true) // Hide the back button specifically for this view
        }
        .navigationViewStyle(StackNavigationViewStyle()) // Use StackNavigationViewStyle for better behavior in the preview
        .disabled(false) // Disable interaction with the view.navigationBarHidden(true) // Hide the navigation bar globally
        .navigationBarBackButtonHidden(true)
    }
    
    func deal() {
        let playerCardValue = Int.random(in: 2...14)
        playerCard = "card" + String(playerCardValue)
        
        //        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
        let cpuCardValue = Int.random(in: 2...14)
        cpuCard = "card" + String(cpuCardValue)
        
        if playerCardValue > cpuCardValue {
            playerScore += 1
        } else if cpuCardValue > playerCardValue {
            cpuScore += 1
            //            }
            
        }
        checkGameStatus()
    }
    
    func checkGameStatus() {
        
        
        if playerScore >= 20 || cpuScore >= 20 {
            gameEnded = true
            winner = playerScore >= 20 ? "Player" : "CPU"

        }
    }
    
    
    func resetGame() {
        playerCard = "card7"
        cpuCard = "card13"
        playerScore = 0
        cpuScore = 0
        gameEnded = false
    }
    
}





struct WarCardGame_Previews: PreviewProvider {
    static var previews: some View {
        WarCardGame()
    }
}
