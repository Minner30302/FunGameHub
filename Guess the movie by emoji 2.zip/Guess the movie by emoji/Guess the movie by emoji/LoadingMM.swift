//
//  LoadingMM.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 4/8/24.
//
import SwiftUI

struct LoadingMM: View {
    @State private var isLoading = false
    @State private var isLoaded = false // Added state for tracking loading completion
    
    var body: some View {
        NavigationView { // Wrap the content in a NavigationView
            ZStack {
                // Gradient background
                LinearGradient(gradient: Gradient(colors: [Color.blue, Color.red]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                
                VStack {
                    // Spinner animation
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        .frame(width: 60, height: 60) // Adjust size as needed
                        .position(x: UIScreen.main.bounds.width / 2, y: UIScreen.main.bounds.height / 2 - 40) // Adjust position
                        .scaleEffect(2.0, anchor: .center)
                        .animation(.easeInOut(duration: 2.0).repeatForever(), value: isLoading)
                    
                    // Loading text positioned under the loading animation
                    Text("Loading...")
                        .font(.headline)
                        .foregroundColor(.white)
                        .offset(x:0,y:-270) // Adjust padding as needed
                }
                .onAppear {
                    isLoading = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                        isLoading = false
                        isLoaded = true // Mark loading as complete
                    }
                }
                .navigationBarBackButtonHidden(true)
                
                // NavigationLink to transition to another view when loading is complete
                NavigationLink(destination: ContentView(), isActive: $isLoaded) {
                    EmptyView()
                }
                .hidden() // Hide the NavigationLink visually
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}

struct Loading: View {
    var body: some View {
        Text("Loaded Content")
            .font(.title)
            .foregroundColor(.black)
    }
}

struct LoadingMM_Previews: PreviewProvider {
    static var previews: some View {
        LoadingMM()
    }
}

