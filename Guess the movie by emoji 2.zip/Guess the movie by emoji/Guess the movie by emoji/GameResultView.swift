//
//  GameResultView.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 4/15/24.
//
import SwiftUI

struct GameResultView: View {
    var wins: Int
    var losses: Int
    @State private var navigateToDifferentView = false
    
    var body: some View {
        NavigationStack{
            VStack(spacing: 20) {
                Text("Game Over")
                    .font(.title)
                    .foregroundColor(.white)
                
                Text(outcomeText)
                    .font(.headline)
                    .foregroundColor(outcomeColor)
                
                Text("Wins: \(wins)")
                    .foregroundColor(.white)
                
                Text("Losses: \(losses)")
                    .foregroundColor(.white)
                
                Button("Exit Game") {
                    navigateToDifferentView = true
                }
                .foregroundColor(.white)
                .padding()
                .background(Color.blue)
                .cornerRadius(10)
                .shadow(radius: 5)
                .padding()
                
                NavigationLink("", destination: GuessPage3(), isActive: $navigateToDifferentView)
                    .frame(width: 0, height: 0)
                    .opacity(0)
            }
            
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color.green]), startPoint: .top, endPoint: .bottom))
            .edgesIgnoringSafeArea(.all)
        }
        .navigationBarBackButtonHidden(true)
        
        var outcomeText: String {
            if wins > losses {
                return "Congratulations! You Win!"
            } else if wins < losses {
                return "Better luck next time. You Lose!"
            } else {
                return "It's a Draw!"
            }
        }
        
        var outcomeColor: Color {
            if wins > losses {
                return .green
            } else if wins < losses {
                return .red
            } else {
                return .yellow
            }
        }
    }
}

struct GameResultView_Previews: PreviewProvider {
    static var previews: some View {
        GameResultView(wins: 5, losses: 3)
    }
}
