//
//  SaveCode.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 3/6/24.
//

import SwiftUI

struct SaveCode: View {
    
    @State var Movie1Showing : Bool = false
    @State var ColorOne : Color = .blue
    var body: some View {
        Text("Hello")
      
        
        
        Button(action: {
            Movie1Showing.toggle()
            ColorOne = .cyan
        }, label: {
            Text("") .padding(20)
                .background(ColorOne)
                .clipShape(Capsule())
                .font(.title)
        })
        .padding(25)
        .sheet(isPresented:$Movie1Showing){
            Text("")
                .font(.largeTitle)
            Button("Dismiss"){
                Movie1Showing.toggle()
                // ColorOne = .blue (optional)
            }
            .frame(width: 200, height: 30)
            .background(.thinMaterial)
        }
     
        
        
        
        
        
        
        
        
 
    }
}

#Preview {
    SaveCode()
}
