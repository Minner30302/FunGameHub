//
//  Guess_the_movie_by_emojiApp.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 3/5/24.
//

import SwiftUI

@main
struct Guess_the_movie_by_emojiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
              
        }
    }
}
