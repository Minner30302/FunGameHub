//
//  Coming Soon.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 3/8/24.
//

import SwiftUI

import SwiftUI

struct Coming_Soon: View {
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.gray, Color.black]), startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            
            VStack {
                Image(systemName: "hourglass")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 100, height: 100)
                    .foregroundColor(.white)
                
                Text("Coming Soon")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.top, 20)
            }
        }
    }
}

struct Coming_Soon_Previews: PreviewProvider {
    static var previews: some View {
        Coming_Soon()
    }
}


#Preview {
    Coming_Soon()
}
