//
//  LoadingViewGP.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 4/8/24.
//
import SwiftUI

struct LoadingViewGP: View {
    @State private var isLoading = false
    @State private var isLoaded = false // Added state for tracking loading completion
    
    var body: some View {
        NavigationView {
            ZStack {
                // Gradient background
                LinearGradient(gradient: Gradient(colors: [Color.blue, Color.red]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                
                VStack {
                    // Spinner animation
                    Circle()
                        .trim(from: 0, to: 0.7) // Adjust the trim to change the loading progress
                        .stroke(Color.white, lineWidth: 5)
                        .frame(width: 80, height: 80)
                        .rotationEffect(.degrees(isLoading ? 360 : 0))
                        .animation(.linear(duration: 1.0).repeatForever(), value: isLoading)
                        .onAppear {
                            isLoading = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                isLoading = false
                                isLoaded = true // Mark loading as complete
                            }
                        }
                    
                    // Loading text
                    Text("Loading...")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.top, 20)
                }
                .navigationBarBackButtonHidden(true)
                
                // NavigationLink to transition to another view when loading is complete
                NavigationLink(
                    destination: GuessPage(),
                    isActive: $isLoaded,
                    label: { EmptyView() }
                )
                .hidden() // Hide the NavigationLink visually
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}

struct LoadingViewGP_Previews: PreviewProvider {
    static var previews: some View {
        LoadingViewGP()
    }
}
