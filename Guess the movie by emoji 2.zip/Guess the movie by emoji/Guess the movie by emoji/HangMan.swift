//
//  HangMan.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 4/22/24.
//
import SwiftUI

struct HangMan: View {
    let hangmanWords: [HangmanWord] = [
        HangmanWord(word: "hangman", hint: "a game played by guessing a hidden word"),
        HangmanWord(word: "apple", hint: "a fruit with a hard core that grows on tree's"),
        HangmanWord(word: "swift", hint: "moving very fast"),
        HangmanWord(word: "coding", hint: "writing instructions for computers"),
        HangmanWord(word: "challenge", hint: "a difficult task or problem"),
        HangmanWord(word: "happy", hint: "feeling joy or contentment"),
        HangmanWord(word: "idea", hint: "a thought or concept"),
        HangmanWord(word: "hello", hint: "a greeting"),
        HangmanWord(word: "can", hint: "a container for liquids"),
        HangmanWord(word: "dog", hint: "the first domesticated animal kept as a pet"),
        HangmanWord(word: "programming", hint: "writing code for software applications"),
        HangmanWord(word: "Sonic", hint: "a popular video game character"),
        HangmanWord(word: "xcode", hint: "an integrated development environment for macOS"),
        HangmanWord(word: "playground", hint: "an area for children to play"),
        HangmanWord(word: "learning", hint: "acquiring new knowledge or skills"),
        HangmanWord(word: "keyboard", hint: "an input device used for typing and interacting with computers"),
        HangmanWord(word: "hammer", hint: "a tool for driving nails"),
        HangmanWord(word: "pizza", hint: "New york's second biggest controversy"),
        HangmanWord(word: "power", hint: "_____ grid's give your house electricity"),
        HangmanWord(word: "shadow", hint: "a dark area caused by blocking light"),
        HangmanWord(word: "game", hint: "an activity for entertainment"),
        HangmanWord(word: "laptop", hint: "teachers best friend tech wise"),
        HangmanWord(word: "chop sticks", hint: "white man's worst enemy and asain man's bestfriend"),
        HangmanWord(word: "pan", hint: "a cooking tool, a newly found sextuality"),
        HangmanWord(word: "pool", hint: "(8),(5),(1),(0), -> corner pocket"),
        HangmanWord(word: "Jayden", hint: "extremely dumb"),
        
    ]
    
    @State private var hiddenWord = ""
    @State private var displayedWord = ""
    @State private var guessedLetter = ""
    @State private var incorrectGuesses = 0
    @State private var correctWordsCount = 0
    @State private var currentRound = 1
    @State private var isAnimating = false
    @State private var showAlert = false
    @State private var guessedLetters: [String] = []
    @State private var incorrectLettersString = ""
    @State private var correctWords: [String] = [] // New property to keep track of correctly guessed words
    @State private var showHint = false // State to control hint visibility
    
    @Environment(\.presentationMode) var presentationMode // Access the presentation mode
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [.black, .blue]), startPoint: .top, endPoint: .bottom)
                    .animation(.easeInOut(duration: 2))
                    .ignoresSafeArea()
                
                VStack {
                    HStack {
                        Text(displayedWord)
                            .font(.largeTitle)
                            .foregroundColor(.white)
                            .padding()
                        Spacer()
                    }
                    Text("Incorrect letters: \(incorrectLettersString)")
                        .foregroundColor(.white)
                        .padding()
                    
                    TextField("Enter a letter", text: $guessedLetter)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                        .autocapitalization(.none)
                        .textContentType(.oneTimeCode)
                    
                    Button(action: guessLetter) {
                        Text("Guess")
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                    
                    Text("Incorrect guesses: \(incorrectGuesses)/6") // Display incorrect guesses count
                        .foregroundColor(.red)
                        .padding()
                    
                    Text("Correct words: \(correctWords.count)") // Display the number of correct words
                        .foregroundColor(.white)
                        .padding()
                    
                    Text("Round: \(currentRound)")
                        .foregroundColor(.white)
                        .padding()
                    
                    if showHint {
                        if let description = hangmanWords.first(where: { $0.word == hiddenWord })?.hint {
                            Text("Hint: \(description)")
                                .foregroundColor(.yellow)
                                .padding()
                        }
                    }
                    
                    if incorrectGuesses >= 3 && !showHint {
                        Button(action: {
                            showHint = true
                        }) {
                            Text("Hint")
                                .padding()
                                .background(Color.gray)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                        .padding(.top)
                    }
                }
                .padding()
                .alert(isPresented: $showAlert) {
                    Alert(title: Text("End of Round \(currentRound)"), message: Text("The correct word was: \(hiddenWord)"), primaryButton: .default(Text("Next Round")) {
                        nextRound()
                    }, secondaryButton: .cancel(Text("Back to Level Select")) {
                        presentationMode.wrappedValue.dismiss() // Dismiss the HangMan view and go back to LevelSelect
                    })
                }
            }
        }
        .navigationBarBackButtonHidden(true)
        .onAppear {
            startGame()
            withAnimation {
                isAnimating.toggle()
            }
        }
    }
    
    private func guessLetter() {
        guard guessedLetter.count == 1 else { return }
        let letter = guessedLetter.lowercased()
        guessedLetter = ""
        
        // Check if the letter has already been guessed
        if guessedLetters.contains(letter) {
            return // Exit the function if the letter has already been guessed
        }
        
        guessedLetters.append(letter) // Add guessed letter to the list
        
        if hiddenWord.lowercased().contains(letter) {
            // Letter is in the word
            var newDisplayedWord = ""
            for char in hiddenWord {
                if guessedLetters.contains(String(char)) || letter == String(char).lowercased() {
                    newDisplayedWord += String(char)
                } else {
                    newDisplayedWord += "-"
                }
            }
            displayedWord = newDisplayedWord
            
            if !displayedWord.contains("-") {
                // Word guessed correctly
                correctWordsCount += 1
                correctWords.append(hiddenWord)
                showAlert = true
                
                if correctWordsCount == hangmanWords.count {
                    // All words guessed correctly, show alert for round completion
                    showAlert = true
                }
            }
        } else {
            incorrectGuesses += 1
            incorrectLettersString += "\(letter) "
            
            if incorrectGuesses >= 6 {
                // Player loses the current round after 6 incorrect guesses
                showAlert = true
            }
        }
    }
    
    private func startGame() {
        let randomWord = hangmanWords.randomElement()!
        hiddenWord = randomWord.word.lowercased()
        displayedWord = String(repeating: "-", count: hiddenWord.count)
        guessedLetter = ""
        incorrectGuesses = 0
        guessedLetters = []
        incorrectLettersString = ""
        showHint = false // Reset hint visibility
    }
    
    private func nextRound() {
        currentRound += 1
        correctWordsCount = 0
        startGame()
    }
}

struct HangMan_Previews: PreviewProvider {
    static var previews: some View {
        HangMan()
    }
}

struct HangmanWord {
    let word: String
    let hint: String
}
