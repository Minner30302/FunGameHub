//
//  ClassView.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 4/2/24.
//

import SwiftUI

class ClassView: ObservableObject {
    @Published   var noun = ""
    @Published   var noun2 = ""
    @Published   var verb = ""
    @Published   var adj = ""
}
