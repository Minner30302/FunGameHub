//
//  GuessPage.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 3/5/24.
//
import SwiftUI

struct GuessPage: View {
    @State var Movie1Showing: Bool = false
    @State var ColorOne: Color = .green
    @State var Movie2Showing: Bool = false
    @State var ColorTwo: Color = .green
    @State var Movie3Showing: Bool = false
    @State var ColorThree: Color = .green
    @State var Movie4Showing: Bool = false
    @State var ColorFour: Color = .green
    @State var Movie5Showing: Bool = false
    @State var ColorFive: Color = .green
    @State var Movie6Showing: Bool = false
    @State var ColorSix: Color = .green
    @State var Movie7Showing: Bool = false
    @State var ColorSeven: Color = .green
    @State var Movie8Showing: Bool = false
    @State var ColorEight: Color = .green
    
    @State private var textColor: Color = .white
    
    var body: some View {
        
        
        NavigationStack{
            ZStack{
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.12), Color.blue.opacity(0.8)]), startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                
                ScrollView{
                    VStack{
                        Text("Guess the Movie/TV Show")
                            .font(.title)
                            .fontDesign(.rounded)
                            .foregroundColor(textColor)
                            .border(Color.black, width: 1) // Add border
                            .scaleEffect(1.2) // Initial scale
                            .padding()
                            .lineLimit(1) // Limit to one line
                            .minimumScaleFactor(0.5) // Allow scaling down
                            .padding(.top, 20)
                        
                        NavigationLink {
                            LoadingGPMM()
                        } label: {
                            Text("Back to Start")
                                .frame(width: 120, height: 40)
                                .foregroundColor(.white)
                                .shadow(color: .black, radius: 10)
                                .background(.blue)
                                .clipShape(Capsule())
                            
                        }
                        Divider()
                        
                        Button(action: {
                            Movie1Showing.toggle()
                            ColorOne = .cyan
                        }) {
                            Text("🟦-🦔") .padding(20)
                                .background(ColorOne)
                                .clipShape(Capsule())
                                .font(.title)
                        }
                        .padding(10)
                        .sheet(isPresented: $Movie1Showing) {
                            Text("Sonic")
                                .font(.largeTitle)
                            Image("SonicH")
                            Button("Dismiss") {
                                Movie1Showing.toggle()
                            }
                            .frame(width: 200, height: 30)
                            .background(.thinMaterial)
                        }
                        
                        Divider()
                        
                        Button(action: {
                            Movie2Showing.toggle()
                            ColorTwo = .cyan
                        }) {
                            Text("🕵🏻‍♂️-👨‍👩‍👧‍👦") .padding(20)
                                .background(ColorTwo)
                                .clipShape(Capsule())
                                .font(.title)
                        }
                        .padding(10)
                        .sheet(isPresented: $Movie2Showing) {
                            Image("SpyKids")
                            Button("Dismiss") {
                                Movie2Showing.toggle()
                            }
                            .frame(width: 200, height: 30)
                            .background(.thinMaterial)
                        }
                        
                        Divider()
                        
                        Button(action: {
                            Movie3Showing.toggle()
                            ColorThree = .cyan
                        }) {
                            Text("🐻-🎩") .padding(20)
                                .background(ColorThree)
                                .clipShape(Capsule())
                                .font(.title)
                        }
                        .padding(10)
                        .sheet(isPresented: $Movie3Showing) {
                            Text("Paddington")
                                .font(.largeTitle)
                            Image("Paddington")
                            Button("Dismiss") {
                                Movie3Showing.toggle()
                            }
                            .frame(width: 200, height: 30)
                            .background(.thinMaterial)
                        }
                        
                        Divider()
                        
                        Button(action: {
                            Movie4Showing.toggle()
                            ColorFour = .cyan
                        }) {
                            Text("👨🏻🟥-🙎🏻‍♂️🟩") .padding(20)
                                .background(ColorFour)
                                .clipShape(Capsule())
                                .font(.title)
                        }
                        .padding(10)
                        .sheet(isPresented: $Movie4Showing) {
                            Text("Mario & Lugi")
                                .font(.largeTitle)
                            Image("MandL")
                            Button("Dismiss") {
                                Movie4Showing.toggle()
                            }
                            .frame(width: 200, height: 30)
                            .background(.thinMaterial)
                        }
                        
                        Divider()
                        
                        Button(action: {
                            Movie5Showing.toggle()
                            ColorFive = .cyan
                        }) {
                            Text("👦🏻-👻-🏚️") .padding(20)
                                .background(ColorFive)
                                .clipShape(Capsule())
                                .font(.title)
                        }
                        .padding(10)
                        .sheet(isPresented: $Movie5Showing) {
                            Image("CasperTheGhost")
                            Button("Dismiss") {
                                Movie5Showing.toggle()
                            }
                            .frame(width: 200, height: 30)
                            .background(.thinMaterial)
                        }
                        
                        Divider()
                        
                        Button(action: {
                            Movie7Showing.toggle()
                            ColorSeven = .cyan
                        }) {
                            Text("🫖-🧞‍♂️-🟪<-(Rug)") .padding(20)
                                .background(ColorSeven)
                                .clipShape(Capsule())
                                .font(.title)
                        }
                        .padding(10)
                        .sheet(isPresented: $Movie7Showing) {
                            Image("Aladdin")
                            Button("Dismiss") {
                                Movie7Showing.toggle()
                            }
                            .frame(width: 200, height: 30)
                            .background(.thinMaterial)
                        }
                        
                        Divider()
                        
                        Button(action: {
                            Movie8Showing.toggle()
                            ColorEight = .cyan
                        }) {
                            Text("🔥-💧-🌳-☁️") .padding(20)
                                .background(ColorEight)
                                .clipShape(Capsule())
                                .font(.title)
                        }
                        .padding(10)
                        .sheet(isPresented: $Movie8Showing) {
                            Image("Elemental")
                            Button("Dismiss") {
                                Movie8Showing.toggle()
                            }
                            .frame(width: 200, height: 30)
                            .background(.thinMaterial)
                        }
                        
                        Divider()
                        
                    }
                }
            }
        }
        .navigationBarBackButtonHidden(true)
    }
    
    struct GuessPage_Previews: PreviewProvider {
        static var previews: some View {
            GuessPage()
        }
    }
}
