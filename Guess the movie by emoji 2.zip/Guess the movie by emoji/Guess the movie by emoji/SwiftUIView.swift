//
//  SwiftUIView.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 4/26/24.
//
import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        VStack {
            Text("Game Down UnderRepair")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.white)
                .padding()
                .background(
                    LinearGradient(
                        gradient: Gradient(colors: [Color(red: 255/255, green: 204/255, blue: 102/255), Color(red: 255/255, green: 153/255, blue: 51/255)]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .cornerRadius(10)
                .shadow(radius: 5)
                .padding()
        }
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIView()
    }
}
