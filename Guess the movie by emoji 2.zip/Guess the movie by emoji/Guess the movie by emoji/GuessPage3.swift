//
//  GuessPage3.swift
//  Guess the movie by emoji
//
//  Created by Lopez, Emre - Student on 3/8/24.
//
import SwiftUI

//struct FireEffect: View {
//    @State private var rotation: CGFloat = 0.0
//    @State private var gradientColors: [Color] = [.red, .orange, .yellow, .orange, .red]
//    
//    var body: some View {
//        LinearGradient(gradient: Gradient(colors: gradientColors), startPoint: .top, endPoint: .bottom)
//            .ignoresSafeArea()
//            .onAppear {
//                withAnimation(Animation.easeInOut(duration: 1).repeatForever(autoreverses: true)) {
//                    if (rotation >= 180) {
//                        rotation = 0
//                    } else {
//                        rotation += 0.0001;
//                    }
//                }
//            }
////            .rotation3DEffect(
////                .zero, axis: (x: rotation, y: CGFloat(0.0), z: CGFloat(0.0))
////            )
//    }
//}
struct FireEffect: View {
    @State private var gradientColors: [Color] = [.blue, .purple, .teal]
    
    var body: some View {
        LinearGradient(gradient: Gradient(colors: gradientColors), startPoint: .top, endPoint: .bottom)
            .ignoresSafeArea()
            .onAppear {
                withAnimation(Animation.linear(duration: 2).repeatForever(autoreverses: true)) {
                    self.gradientColors.shuffle()
                }
            }
    }
}

struct GuessPage3: View {
    init() {
        // Customize the appearance of the back button
        UINavigationBar.appearance().backIndicatorImage = UIImage(systemName: "arrow.left")
        UINavigationBar.appearance().backIndicatorTransitionMaskImage = UIImage(systemName: "arrow.left")
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                FireEffect()
                
                VStack {
                    Spacer()
                    
                    Text("Rock-Paper-Scissors")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .shadow(color: Color .black, radius: 5)
                        .padding(.bottom, 20)
                    
                    VStack {
                        Text("Rules:\n1. play until the game stops\n20 rounds is the max\n\n2.  Only One player at a time")
                            .font(.headline)
                            .foregroundColor(Color.white.opacity(0.9)) // Light gray
                            .multilineTextAlignment(.center)
                            .padding(20)
                    }
                    .background(Color.black.opacity(0.3))
                    .frame(width: 320, height: 220)
                    .padding()
                    
                    NavigationLink(destination: Rock_Paper_Scissors()) {
                        Text("Start")
                            .frame(width: 120, height: 50)
                            .foregroundColor(.white)
                            .background(Color.green)
                            .clipShape(Capsule())
                            .shadow(color: .black, radius: 5)
                            .padding(.vertical, 10)
                    }
                    .position(x: UIScreen.main.bounds.width / 2, y: UIScreen.main.bounds.height / 100)
                    
                    NavigationLink(destination: Level_Select()) {
                        Text("Back to Selection")
                            .frame(width: 120, height: 50)
                            .foregroundColor(.white)
                            .background(Color.green)
                            .clipShape(Capsule())
                            .shadow(color: .black, radius: 5)
                            .padding(.vertical, 10)
                    }
                    .position(x: UIScreen.main.bounds.width / 2, y: UIScreen.main.bounds.height / 100)
                    
                    Spacer()
                }
            }
            .navigationBarTitle("", displayMode: .inline) // Custom empty title
        }
        .navigationBarBackButtonHidden(true)
    }
}

struct GuessPage3_Previews: PreviewProvider {
    static var previews: some View {
        GuessPage3()
    }
}
